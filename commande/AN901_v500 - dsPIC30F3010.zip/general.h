//--------------------- Common stuff for C routines ---------------------

#include <p30F3010.h>

