// parameters.h

// Note:  The software parameters contained in this file have
// been relocated to user_interface.c

