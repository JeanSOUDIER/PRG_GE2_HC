/**********************************************************************
 *                                                                     *
 *                        Software License Agreement                   *
 *                                                                     *
 *    The software supplied herewith by Microchip Technology           *
 *    Incorporated (the "Company") for its dsPIC controller            *
 *    is intended and supplied to you, the Company's customer,         *
 *    for use solely and exclusively on Microchip dsPIC                *
 *    products. The software is owned by the Company and/or its        *
 *    supplier, and is protected under applicable copyright laws. All  *
 *    rights are reserved. Any use in violation of the foregoing       *
 *    restrictions may subject the user to criminal sanctions under    *
 *    applicable laws, as well as to civil liability for the breach of *
 *    the terms and conditions of this license.                        *
 *                                                                     *
 *    THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION.  NO           *
 *    WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,    *
 *    BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND    *
 *    FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE     *
 *    COMPANY SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL,  *
 *    INCIDENTAL OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.  *
 *                                                                     *
  **********************************************************************/

 /**********************************************************************
 *                                                                     * 
 *    Author: Smart Power Soutions, LLP                                * 
 *                                                                     *
 *    Filename:       lcd_messages.h  	                               *
 *    Date:           11/01/06                                         *
 *    File Version:   5.10                                             *
 *    Project:        53                                               *
 *    Drawing:        2                                                *
 *                                                                     *
 *    Tools used:    MPLAB C30 Compiler v 2.03                         *
 *                                                                     *
 *    Linker File:    p30f6010a.gld                                     *
 *                                                                     *
 *                                                                     *
 ***********************************************************************
 *	Code Description
 *  
 * This file contains all the different fixed lcd messages
 * except those associated with parameter editing which are
 * in parameters.h
 * Note that it is assumed that these will be used as is with
 * no screen blank and so extra spaces are always required to
 * pad the length of the lines to 16 characters.
 *
 **********************************************************************/

const unsigned char line1_boot_message[] = "dsPIC BLDC Demo ";				
const unsigned char line2_boot_message[] = "V5.10 Nov 01 06 ";

const unsigned char line1_standby_message[] = 		"V5.10 STANDBY   ";
const unsigned char line2_standby_message[] =		"S7-START,S4-EDIT";

const unsigned char line1_fault_message[]=			"FAULT DETECTED! ";
const unsigned char line2_fault_message[7][17]={	"FAILED TO START ",
																	" OVER CURRENT   ",
																	" OVER VOLTAGE   ",
																	" HARDWARE TRIP  ",
																	"   OVER SPEED   ",
																	"SENSORLESS LOST ",
																	" MOTOR STALLED  "};

const unsigned char line1_reset_message[] = 	"System Resetting";
const unsigned char line2_reset_message[] =  "  Please Wait   ";

const unsigned char line1_starting_message[] = 	"System Starting ";
const unsigned char line2_starting_message[] =  "  Please Wait   ";

																		
const unsigned char lcd_mode_msg[4][13]={	"CLOSED VOLTS",
														"CLOSED CURNT",
														"  OPEN VOLTS",
														"OPEN CURRENT"};
