/**********************************************************************
 *                                                                     *
 *                        Software License Agreement                   *
 *                                                                     *
 *    The software supplied herewith by Microchip Technology           *
 *    Incorporated (the "Company") for its dsPIC controller            *
 *    is intended and supplied to you, the Company's customer,         *
 *    for use solely and exclusively on Microchip dsPIC                *
 *    products. The software is owned by the Company and/or its        *
 *    supplier, and is protected under applicable copyright laws. All  *
 *    rights are reserved. Any use in violation of the foregoing       *
 *    restrictions may subject the user to criminal sanctions under    *
 *    applicable laws, as well as to civil liability for the breach of *
 *    the terms and conditions of this license.                        *
 *                                                                     *
 *    THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION.  NO           *
 *    WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,    *
 *    BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND    *
 *    FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE     *
 *    COMPANY SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL,  *
 *    INCIDENTAL OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.  *
 *                                                                     *
  **********************************************************************/

 /**********************************************************************
 *                                                                     * 
 *    Author: Smart Power Soutions, LLP                                * 
 *                                                                     *
 *    Filename:       hardware.h                                       *
 *    Date:           11/01/06                                         *
 *    File Version:   5.10                                             *
 *    Project:        53                                               *
 *    Drawing:        2                                                *
 *                                                                     *
 *    Tools used:    MPLAB C30 Compiler v 2.03                         *
 *                                                                     *
 *    Linker File:    p30f6010a.gld                                    *
 *                                                                     *
 *                                                                     *
 ***********************************************************************
 *	Code Description
 *  
 * This file contins details of the hardware for the project
 * PCB : dsPIC30F Motor Control Development PCB 02-01648 REVB
 *
 **********************************************************************/

// This is the clock frequency in Hz including any PLL factor
#define CLOCK_FREQ 29491200 // Assuming 7.3728MHz and X4 PLL

// NB Using LAT Registers rather than PORT registers
// to prevent any read/modify/write issues with outputs

// These are the pushbutton pin connections
#define	BUTTON1	!PORTGbits.RG6		//S4 on PCB
#define	BUTTON2	!PORTGbits.RG7		//S5 on PCB
#define	BUTTON3	!PORTGbits.RG8		//S6 on PCB
#define	BUTTON4	!PORTGbits.RG9		//S7 on PCB
#define TRIP_BUTTON !PORTEbits.RE8	//S3 on PCB

// These are the LEDs
#define DIR_LED LATDbits.LATD7		//D5 on PCB
#define LED1 LATAbits.LATA9			//D6 on PCB
#define LED2 LATAbits.LATA10			//D7 on PCB
#define LED3 LATAbits.LATA14			//D8 on PCB
#define LED4 LATAbits.LATA15			//D9 on PCB

// This is the control line for the driver IC for the firing signals
// It must be low to activate the signals to the power module.
#define	PWM_OUTPUT_DISABLE LATDbits.LATD11

// Also declare some useful shortcuts
#define DISABLE_FIRING PWM_OUTPUT_DISABLE=1
#define ENABLE_FIRING PWM_OUTPUT_DISABLE=0

// This is the reset line for the hardware faults in the power module.
// It is also used to reset the 12C671 providing the isolated
// feedback of the |Vac| and Vdc signals. Therefore the min high time
// is 4us to allow for the opto and to ensure 12C671 has pulse > 2us.
#define FAULT_RESET	LATEbits.LATE9

// This the RS485_TXENA (active high line)
#define RS485_TXENA LATGbits.LATG1

// This the RS485_RXENA (active LOW line)
#define RS485_RXENA !LATGbits.LATG0

// The following definitions are provided to allow direct
// access to peripheral output pins for development and testing.

// PFC switch firing line
#define	PFC_FIRE	LATDbits.LATD5

// BRAKE circuit firing line
#define BRAKE_FIRE	LATDbits.LATD4

//This is the RS485_TX line
#define RS485_TX LATFbits.LATF5

//This is the RS485_RX line
#define RS485_RX PORTFbits.RF4

//This is the CAN_TX line
#define CAN_TX LATFbits.LATF1

//This is the CAN_RX line
#define CAN_RX PORTFbits.RF0

//This is the RS232_TX line
#define RS232_TX LATFbits.LATF3

//This is the RS232_RTS line
#define RS232_RTS LATGbits.LATG2

//This is the RS232_RX line
#define RS232_RX PORTFbits.RF2

//This is the RS232_CTS line
#define RS232_CTS PORTGbits.RG3


