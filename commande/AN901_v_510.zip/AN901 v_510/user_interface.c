/**********************************************************************
 *                                                                     *
 *                        Software License Agreement                   *
 *                                                                     *
 *    The software supplied herewith by Microchip Technology           *
 *    Incorporated (the "Company") for its dsPIC controller            *
 *    is intended and supplied to you, the Company's customer,         *
 *    for use solely and exclusively on Microchip dsPIC                *
 *    products. The software is owned by the Company and/or its        *
 *    supplier, and is protected under applicable copyright laws. All  *
 *    rights are reserved. Any use in violation of the foregoing       *
 *    restrictions may subject the user to criminal sanctions under    *
 *    applicable laws, as well as to civil liability for the breach of *
 *    the terms and conditions of this license.                        *
 *                                                                     *
 *    THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION.  NO           *
 *    WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,    *
 *    BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND    *
 *    FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE     *
 *    COMPANY SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL,  *
 *    INCIDENTAL OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.  *
 *                                                                     *
  **********************************************************************/

 /**********************************************************************
 *                                                                     * 
 *    Author: Smart Power Soutions, LLP                                * 
 *                                                                     *
 *    Filename:       user_interface.c                                 *
 *    Date:           11/01/06                                         *
 *    File Version:   5.10                                             *
 *    Project:        53                                               *
 *    Drawing:        2                                                *
 *                                                                     *
 *    Tools used:    MPLAB C30 Compiler v 2.03                         *
 *                                                                     *
 *    Linker File:    p30f6010a.gld                                    *
 *                                                                     *
 *                                                                     *
 ***********************************************************************
 *	Code Description
 *  
 *  This file contains all the code for implementing the user interface.
 *  The user interface functions are called from the slow event handler,
 *  which runs every 100 msec.
 *  Different screens are called depending on the operating state of the
 *  software.  The process_switches() function uses the debounced push
 *  buttons and determines the length of time the button has been 
 *  pressed for fast incrementing of the parameter. It also moves the 
 *  system between the various states according to the push buttons.
 *  The SaveToEEPROM() function saves a changed parameter to EEPROM.
 *  The process_parameters() function does any scaling or units
 *  conversion that is required for the stored parameters.
 **********************************************************************/


#include "general.h"
#include "hardware.h"
#include "defs.h"
#include "extern_globals.h"
#include "lcd_messages.h"
#include "xlcd.h"

/*********************************************************************/
struct parameter_data 
{
    	unsigned int min;		/*minimum allowed value */
    	unsigned int max;    /*maximum allowed value */
    	unsigned int med;		/*the medium rate parameter increment*/
		unsigned int fast;	/*the fast rate parameter increment*/
    	char *line1_msg;     /*line 1 parameter screen message */
		char *units_msg;		/*units message used for RHS line 2*/
    };

const struct parameter_data parameter_data [] =	{
/* Min, Max, Med delta, Fast delta, Line1 msg, Units msg */
{0,1,1,1,				"DIRECTION DEMAND"," FWD/BKWD"},//0
{0,3,1,1,				"  CONTROL MODE  ","         "},//1
{0,32767,10,100,		"Lock Pos.1  Time"," 10ms/bit"},//2
{0,32767,10,100,		"Lock Pos.2  Time"," 10ms/bit"},//3
{0,100,5,10,			"Lock Pos.1 Dem. "," % Demand"},//4
{0,100,5,10,			"Lock Pos.2 Dem. "," % Demand"},//5
{1,9999,10,100,		"Ramp Start Speed"," Revs/min"},//6
{1,9999,10,100,		"Ramp End   Speed"," Revs/min"},//7
{0,100,2,5,				"Ramp Start Dem. "," % Demand"},//8
{0,100,2,5,				"Ramp End   Dem. "," % Demand"},//9
{1,32767,10,100,		"Ramp Duration   "," 10ms/bit"},//10
{1,32767,10,100,		"Phase Adv. Start"," Revs/min"},//11
{1,32767,10,100,		"Phase Adv. Slope"," see docs"},//12
{1,32767,10,100,		"Stall Time Limit"," 10ms/bit"},//13
{1,32767,10,100,		"Over Speed Limit"," Revs/min"},//14
{1,32767,10,100,		"Over Volts Limit","0.1V/bit "},//15
{1,32767,10,100,		"Over Current Lim","0.1A/bit "},//16
{0,32767,100,500,		"Current P Gain  ","         "},//17
{0,32767,100,500,		"Current I Gain  ","         "},//18
{0,32767,100,500,		"Current D Gain  ","         "},//19
{0,9999,10,100,		"Speed P Gain    ","         "},//20
{0,9999,10,100,		"Speed I Gain    ","         "},//21
{0,32767,10,100,		"Voltage Demand  ","0.1V/bit "},//22
{0,32767,100,500,		"Volts P Gain    ","         "},//23
{0,32767,100,500,		"Volts I Gain    ","         "},//24
{2,48,2,4,				"No. Motor Poles "," Even   !"},//25
{1,3670,10,100,		"Current Scale X ","         "},//26
{1,6550,10,100,		"Current Scale / ","         "},//27
{1,3670,10,100,		"Volts Scale X   ","         "},//28
{1,6550,10,100,		"Volts Scale /   ","         "},//29
{1,100,5,20,			"Tolerance Check "," %       "},//30
{0,1,1,1,				"Auto Re-acquire "," ON / OFF"},//31
{0,255,1,2,				"Blanking Count  ","         "},//32
{0,255,1,2,				"Zero X Level Thd","         "},//33
{1,1023,1,2,			"Acquire Threshld"," ADC VAL "},//34
{0,255,1,2,				"Acquire Level Td","         "},//35
{0,32767,10,100,		"Rotation Timeout"," 10ms/bit"},//36
{1,100,2,10,			"Pot / for Duty  ","         "},//37
{1,100,2,10,			"Pot / for Currnt","         "},//38
{1,64,2,5,				"Pot X for Speed ","         "},//39
{0,1,1,1,				"Starting Control"," 1=V, 0=I"},//40
{0,100,5,10,			"Windmilling Dem."," % Demand"},//41
{1,32767,10,100,		"Braking Ramp T  "," 10ms/bit"},//42
{0,1,1,1,				"Acquire Method  "," see docs"},//43
{1,9999,10,100,		"ZeroX Enable Spd"," Revs/min"},//44
};

volatile unsigned int user_parameters_RAM[NO_PARAMETERS] =
{	FORWARDS,		//	Direction Demand 
	CLOSED_VOLTS,	// Speed Control Mode - See defs.h 
	50,				// First Lock Position Time in units of medium event (10ms) 
	50,				// Second Lock Position Time in units of medium event (10ms) 
	45,				// % Demand Used For Lock Position 1
	45,				// % Demand Used For Lock Position 2			
	10,				// Starting Speed for Ramp / RPM 
	2500,			// Finish Speed for Ramp / RPM	
	55,				// % Demand Used At Start of Ramp
	70,				// % Demand Used At End of Ramp	
	200, 			// Duration of starting ramp in units of medium event (10ms)
	1500,			// Phase Advance Start Speed in RPM 
	25,				// Phase Advance Slope in 1/1000th elec. degree / RPM	
	100,			// Stall Time Limit in units of medium event (10ms) 
	3500,			// Over Speed Trip in RPM	
	500,			//	Over Voltage Trip in 1/10ths V
	100,			// Over Current Limit in 1/10ths A 
	900,			// Current Loop P Gain 
	100,			// Current Loop I Gain 
	0,				// Current Loop D Gain 
	2000,			// Speed Loop P Gain 
	200,			// Speed Loop I Gain 
	490,			// Voltage Demand for Brake Chopper in 1/10ths V 
	10000,			// Voltage Loop P Gain 
	5000,			// Voltage Loop I Gain 
	10,				// Number of Motor Poles 
	100,			// Current Scaling X - see below
	539,			// Current Scaling / - see below
	100,			// Voltage Scaling X - see below
	1305,			// Voltage Scaling / - see below
	99,				// % Tolerance used for Lost Check - see below
	1,				// Auto-reaquire if lost ON/OFF
	2,				// Blanking Length used for zero X in no of ADC samples
	2,				// No. of samples required > or < VDC/2 before zero X checked for
	12,  			// ADC value used for rising edge detect for acquisition routine
	6,				// No of samples of VPH before rising edge detect done in acquisition
	5,				// Rotation Timeout in units of medium event (10ms)
	1,				// Divisor used to scale pot ADC reading to Duty Cycle
	32,				// Divisor used to scale pot ADC reading to I Dem in ADC
	3,				// X Used to Scale pot ADC reading to speed demand in rpm
	1,				// 1=Use Voltage Control for Starting, 0=Use Current Control
	20,				// % Demand Used For Windmilling Braking
	1,				// Duration of braking ramp in units of medium event (10ms)
	0,				// Use Method 1 (=0) or Method 2 (=1) for acquisition of position
	1500};			// Speed at Which ZeroX detection enabled when using method1 acqusition



// Current and Voltage Scaling X and / Parameters
// These are used to scale ADC readings into Amps or Volts as follows: 
// If you get 12.87 A/V for ibus or 12.87 V/V for vdc then
// X = 100 and / = 1287 is one possible combination

// For LV Power Module Use The Following values: 
// VX=100 V/=1305 i.e scaling is 13.05 V/V		 
// If LK11&12 Open 	IX=100 I/=539 i.e scaling is 5.39A/V 
// If LK11&12 Closed	IX=10  I/=119 i.e.scaling is 11.9A/V 

// For HV Power Module Use The Following values: 
// VX=10  V/910 i.e. scaling is 91.0 V/V 
// If LK11&12 Open	IX=100 I/=108 i.e scaling is 1.08A/V 
// if LK11&12 Closed IX=100 I/=239 i.e scaling is 2.39A/V 

// Tolerance for Lost Check Parameter 
// Every 60 electrical degrees a new zero crossing event should
// be detected. In order to determine if the system is lost, 
// a check is carried out comparing the time elapsed since the 
// last zero crossing and the one before that. 
// If the tolerance parameter is set to 25% then up to 25%
// variation between the two times is considered to be acceptable.
// If the system fails the check, then the system is lost.
// Some natural variation in the times is to be expected even at
// a constant speed due to timer and ADC resolution as well as 
// motor asymmetry. Speed changes will also result in variation.
// It is suggested that the parameter is not set to less than 25%
// as otherwise the system may be determined to lost just due to
// normal variations.
/*********************************************************************/



void screen_handler(void);
void process_switches(void);
void process_parameters(void);
void debounce_switches(void);
void Write_Screen(unsigned const char *,unsigned const char *);
void Edit_Screen(void);
void Run_Screen(void);
void uint_to_string(unsigned int, unsigned char *);

extern void erase_flash_row(unsigned int);
extern void program_flash(unsigned int, unsigned int);

struct interface_flags {
				unsigned EDIT_PARAM : 1;
				unsigned EDIT_MENU :	1;
				unsigned PARAM_CHANGING	: 1;
				unsigned S4_RISING :1;
				unsigned S5_RISING :1;
				unsigned S6_RISING :1;
				unsigned S7_RISING :1;
				unsigned RUN_FRAME :1;
				unsigned UNUSED : 8;
};

struct interface_flags interface_flags;

void screen_handler(void)
{
	static unsigned char blink_counter=1;
	
	blink_counter++;

	if (blink_counter > 40)	blink_counter=0;

	switch (run_state)
	{
		case RUNNING:	Run_Screen();
							break;
		case FAULT:		
		case STANDBY:	
							process_parameters();
							
							
							if (interface_flags.EDIT_MENU)
							{
								if (interface_flags.EDIT_PARAM)
								{
									if (blink_counter>10) Edit_Screen();
									else	
									{
										if (!interface_flags.PARAM_CHANGING)
											Write_Screen(parameter_data[param].line1_msg, \
													 		"S6 STORE S7 EXIT");
										else	Edit_Screen();
									}
								}
								else
								{
									Write_Screen(parameter_data[param].line1_msg, \
													 		"S6 ALTER S7 EXIT"); 
								}
							}
							else
							{
								if (run_state==FAULT)
								{
									if (blink_counter>10)
										Write_Screen(&line1_fault_message[0],&line2_fault_message[trip_state-1][0]);
									else
										Write_Screen(&line1_fault_message[0], \
													 		"S4 EDIT S7 RESET");
								}
								else
									Write_Screen(&line1_standby_message[0],&line2_standby_message[0]);
							}
							break;

		case INITIALIZING: 	Write_Screen(&line1_boot_message[0],&line2_boot_message[0]);
									break;

		case STARTING:	Write_Screen(&line1_starting_message[0],&line2_starting_message[0]);
							break;
		default:			break;
	}
	return;
}



void process_switches(void)
{
	static unsigned char previous_valid_switch_states=0xFF;
	static unsigned char key_hold_timer=0;
	static unsigned int param_increment=1;

	if ((previous_valid_switch_states==valid_switch_states) \
		&& (interface_flags.EDIT_MENU==FALSE))	
	{
		previous_valid_switch_states=valid_switch_states;
		return;
	}

	if (((previous_valid_switch_states & 0x01)==FALSE) && (valid_switch_states & 0x01))
		interface_flags.S4_RISING=TRUE;
	else
		interface_flags.S4_RISING=FALSE;

	if (((previous_valid_switch_states & 0x02)==FALSE) && (valid_switch_states & 0x02))
		interface_flags.S5_RISING=TRUE;
	else
		interface_flags.S5_RISING=FALSE;

	if (((previous_valid_switch_states & 0x04)==FALSE) && (valid_switch_states & 0x04))
		interface_flags.S6_RISING=TRUE;
	else
		interface_flags.S6_RISING=FALSE;

	if (((previous_valid_switch_states & 0x08)==FALSE) && (valid_switch_states & 0x08))
		interface_flags.S7_RISING=TRUE;
	else
		interface_flags.S7_RISING=FALSE;

	previous_valid_switch_states=valid_switch_states;

	if ((interface_flags.EDIT_MENU==TRUE) && \
		 (interface_flags.EDIT_PARAM==FALSE))
	{
		if (interface_flags.S5_RISING)
		{
			if (param<(NO_PARAMETERS-1))	param++;
			else				param=0;
		}
		if (interface_flags.S4_RISING)
		{
			if (param>0)	param--;
			else				param=(NO_PARAMETERS-1);
		}
		if (interface_flags.S6_RISING)	
		{
			interface_flags.EDIT_PARAM=TRUE;
			new_param_value=user_parameters_RAM[param];
		}
		if (interface_flags.S7_RISING)	interface_flags.EDIT_MENU=FALSE;
		return;
	}
	if (interface_flags.EDIT_PARAM)
	{
		if (key_hold_timer > FAST_RATE_T)	param_increment=parameter_data[param].fast;
		else
		{
			if (key_hold_timer > MED_RATE_T) param_increment=parameter_data[param].med;
			else	param_increment=1;
		}

		if (valid_switch_states & 0x02)
		{
			if (new_param_value < (parameter_data[param].max - param_increment))
				new_param_value+=param_increment;
			else
				new_param_value=parameter_data[param].max;

			if (key_hold_timer<255)	key_hold_timer++;
		}

		if (valid_switch_states & 0x01)
		{
			if (new_param_value > (parameter_data[param].min + param_increment))
				new_param_value-=param_increment;
			else
				new_param_value=parameter_data[param].min;

			if (key_hold_timer<255)	key_hold_timer++;
		}
		if ((!(valid_switch_states & 0x01)) && (!(valid_switch_states & 0x02)))
		{
			key_hold_timer=0;
			interface_flags.PARAM_CHANGING=FALSE;
		}
		else	interface_flags.PARAM_CHANGING=TRUE;

		if (interface_flags.S6_RISING)
		{
			user_parameters_RAM[param]=new_param_value;
			process_parameters();
			param_increment=1;
			interface_flags.EDIT_PARAM=FALSE;
		}
		if (interface_flags.S7_RISING)	
		{
			param_increment=1;
			interface_flags.EDIT_PARAM=FALSE;
		}
		return;
	}

	switch(run_state)
	{
		case INITIALIZING: break;

		case STANDBY:	if (interface_flags.S7_RISING)
							{
								DISABLE_INTERRUPTS;
								control_flags2.ROTATION_CHECK=TRUE;
								control_flags2.WINDMILLING=FALSE;
								control_flags2.RETRY_FLAG=FALSE;
								control_flags.LOCK1=FALSE;
								control_flags.LOCK2=FALSE;
								control_flags.RAMP=FALSE;
								control_flags.SENSORLESS=FALSE;
								control_flags.ACQUIRE2=FALSE;
								control_flags.ACQUIRE1=FALSE;
								control_flags.DIR=user_parameters_RAM[0];
								ENABLE_INTERRUPTS;
								run_state=STARTING;
								interface_flags.EDIT_MENU=FALSE;
								interface_flags.RUN_FRAME=0;
							}
							if (interface_flags.S4_RISING)
								interface_flags.EDIT_MENU=TRUE;
							break;

		case STARTING:	if (interface_flags.S7_RISING)
							{
								DISABLE_FIRING;
								control_flags.SENSORLESS=FALSE;
								control_flags.ACQUIRE2=FALSE;
								IEC0bits.T1IE=FALSE;
								IEC0bits.T2IE=FALSE;
								run_state=STANDBY;
							}
							break;

		case RUNNING: 	if (interface_flags.S7_RISING)
							{
								DISABLE_FIRING;
								control_flags.SENSORLESS=FALSE;
								control_flags.ACQUIRE2=FALSE;
								IEC0bits.T1IE=FALSE;
								IEC0bits.T2IE=FALSE;
								run_state=STANDBY;
							}
							if (interface_flags.S4_RISING)
								interface_flags.RUN_FRAME= !interface_flags.RUN_FRAME;
							break;
		case FAULT:		if (interface_flags.S7_RISING)
							{
								trip_state=NO_TRIP;
								DISABLE_INTERRUPTS;
								control_flags.LOCK1=FALSE;
								control_flags.LOCK2=FALSE;
								control_flags.RAMP=FALSE;
								control_flags.SENSORLESS=FALSE;
								control_flags.ACQUIRE1=FALSE;
								control_flags.ACQUIRE2=FALSE;
								IEC0bits.T1IE=FALSE;
								IEC0bits.T2IE=FALSE;
								ENABLE_INTERRUPTS;
								period_measurement=1000;
								FAULT_RESET=TRUE;
								Write_Screen(&line1_reset_message[0],&line2_reset_message[0]);
								FAULT_RESET=FALSE;
								run_state=STANDBY;
							}
							if (interface_flags.S4_RISING)
								interface_flags.EDIT_MENU=TRUE;
							break;
		default:			break;
	}

	return;
}


// This function does the necessary calculations when a parameter
// value changes. Some parameters values are used directly, others
// form the basis for other variables but these need to be calculated.
void process_parameters(void)
{
	unsigned long ltemp;

	// If a value is missing from this switch statement this implies the
	// user parameter is used directly.
	// Note that parameters that affect other variables should also be in
	// this list e.g.if Voltage scaling changes, voltage demand and trips
	// need to be recalculated.
	
	// Save direction of motor rotation
	control_flags.DIR=user_parameters_RAM[0];

	// Get value reported for ibus
	// At this stage assuming ibus=0 and have first valid sample
	// and so use this one for offset
	ibus_offset=ibus;
	ltemp=((unsigned long)user_parameters_RAM[16])*ADC_GAIN;
	ltemp*=((unsigned long)user_parameters_RAM[26]);
	current_trip=(ltemp/(user_parameters_RAM[27]*10))+ibus_offset;

	// If using voltage control for starting
	if (user_parameters_RAM[40])
	{
		hold1_demand=(unsigned int)((unsigned long)user_parameters_RAM[4])*FULL_DUTY/100;
		hold2_demand=(unsigned int)((unsigned long)user_parameters_RAM[5])*FULL_DUTY/100;
		ramp_start_demand=(unsigned int)((unsigned long)user_parameters_RAM[8])*FULL_DUTY/100;
		ramp_end_demand=(unsigned int)((unsigned long)user_parameters_RAM[9])*FULL_DUTY/100;
	}
	else //Using current control assume scaling is in % of trip
	{
		ltemp=(unsigned long)(current_trip-ibus_offset);
		hold1_demand=(unsigned int)((ltemp*(unsigned long)user_parameters_RAM[4])/100);
		hold2_demand=(unsigned int)((ltemp*(unsigned long)user_parameters_RAM[5])/100);
		ramp_start_demand=(unsigned int)((ltemp*(unsigned long)user_parameters_RAM[8])/100);
		ramp_end_demand=(unsigned int)((ltemp*(unsigned long)user_parameters_RAM[9])/100);
	}	
	ramp_demand_delta = (signed int)(ramp_end_demand-ramp_start_demand);
	windmilling_demand = (unsigned int)((ltemp*(unsigned long)user_parameters_RAM[41])/100);
	
	// Calculate step rates in units of TIMER2 from 
	// user parameters in RPM ensuring no overflows occur
	ltemp=((unsigned long)user_parameters_RAM[6]*(unsigned long)user_parameters_RAM[25])/20;
	// This check ensures that ramp_start_rate is calculated with no overflow
	if ((COUNTER_RATE/ltemp) > 65535)
	{	
		ramp_start_rate=65535;
		ramp_start_speed=COUNTER_RATE*20/(65535*(unsigned long)user_parameters_RAM[25]);
	}
	else
	{
		ramp_start_rate=(unsigned int)(COUNTER_RATE/ltemp);
		ramp_start_speed=user_parameters_RAM[6];
	}
	ltemp=((unsigned long)user_parameters_RAM[7]*(unsigned long)user_parameters_RAM[25])/20;
	// This check ensures that ramp_end_rate is calculated with no overflow
	if ((COUNTER_RATE/ltemp) > 65535)	
		ramp_end_rate=65535;
	else
		ramp_end_rate=(unsigned int)(COUNTER_RATE/ltemp);

	ramp_speed_delta=(int)(user_parameters_RAM[7]-user_parameters_RAM[6]);
	// Also calculate step rate at which zero X detection enabled when using
	// acquistion method 1
	ltemp=((unsigned long)user_parameters_RAM[44]*(unsigned long)user_parameters_RAM[25])/20;
	if ((COUNTER_RATE/ltemp) > 65535)
		acquire1_enable_rate=65535;
	else
		acquire1_enable_rate=(unsigned int)(COUNTER_RATE/ltemp);

	// ramp time is used to hold user_parameters[10] so that
	// it can be directly referenced in some inline assembly 
	ramp_time=user_parameters_RAM[10];
	iloop_p_gain=(int)user_parameters_RAM[17];
	iloop_i_gain=(int)user_parameters_RAM[18];
	iloop_d_gain=(int)user_parameters_RAM[19];
	wloop_p_gain=(int)user_parameters_RAM[20];
	wloop_i_gain=(int)user_parameters_RAM[21];
	vloop_p_gain=(int)user_parameters_RAM[23];
	vloop_i_gain=(int)user_parameters_RAM[24];
		
	// Now calculate the current limits used when in CLOSED_CURRENT
	// speed control as 95% of the current trip levels
	pos_current_limit=(long)(current_trip-ibus_offset)*95/100;
	pos_current_limit*=16384L;
	neg_current_limit=-1*pos_current_limit;

	ltemp=((unsigned long)user_parameters_RAM[28])*ADC_GAIN;
	voltage_trip=(ltemp*(unsigned long)user_parameters_RAM[15])/((unsigned long)user_parameters_RAM[29]*10);
	voltage_demand=(ltemp*(unsigned long)user_parameters_RAM[22])/((unsigned long)user_parameters_RAM[29]*10);

	upper_tol=100+user_parameters_RAM[30];
	lower_tol=100-user_parameters_RAM[30];

	// Calculate acquision (method2) threshold values based
	// on user parameter and ADC value read during initialization.
	// This compensates for offset voltages due to ADC and power module.
	vph_red_threshold=vph_red+user_parameters_RAM[34];
	vph_yellow_threshold=vph_yellow+user_parameters_RAM[34];
	vph_blue_threshold=vph_blue+user_parameters_RAM[34];

	return;

}

// This function does a simple switch debounce by not
// updating the global variable valid_switch_states
// unless all 4 push buttons have been in the same
// state for 3 calls of the function
void debounce_switches(void)
{
	static unsigned char oldest_switch_states=0;
	static unsigned char previous_switch_states=0;
	unsigned char switch_states;

	// The four push buttons are on PORTG6-9 but have pull
	// up resistors making a logic 0 equal to a button press
	// So we complement and shift them down to be aligned to 
	//	the bottom which will also effectively mask off all other bits.

	switch_states=(unsigned char)((~PORTG)>>6);
	
	if (switch_states!=previous_switch_states)
	{
		oldest_switch_states=previous_switch_states;
		previous_switch_states=switch_states;
		return;
	}

	if (previous_switch_states != oldest_switch_states)
	{
		oldest_switch_states=previous_switch_states;
		previous_switch_states=switch_states;
	}
	else
	{
		valid_switch_states=switch_states;
		oldest_switch_states=previous_switch_states;
		previous_switch_states=switch_states;
	}
	return;
}

void Write_Screen(unsigned const char *line1,unsigned const char *line2)
{
    while(BusyXLCD());              	// Wait if LCD busy						
	SetDDRamAddr(0x00);						// sets address to origin
    while(BusyXLCD());             		// Wait if LCD busy
	putsXLCD(line1);				
	
	while(BusyXLCD());              	// Wait if LCD busy
	SetDDRamAddr(0x40);					// Move To Second Line
	while(BusyXLCD());              	// Wait if LCD busy
	putsXLCD(line2);					
    return;
}

void Edit_Screen(void)
{
	unsigned char lcd_char[5];

   while(BusyXLCD());              	// Wait if LCD busy
   SetDDRamAddr(0x00);					// Sets address to origin
   while(BusyXLCD());             	// Wait if LCD busy
	putsXLCD(parameter_data[param].line1_msg);
						
   while(BusyXLCD());              	// Wait if LCD busy
	SetDDRamAddr(0x40);					// Move To Second Line
	while(BusyXLCD());             	// Wait if LCD busy
	uint_to_string(new_param_value,&lcd_char[0]);
	putsXLCD(&lcd_char[0]);
	while(BusyXLCD());              	// Wait if LCD busy
	putsXLCD("  ");			
	while(BusyXLCD());              	// Wait if LCD busy
	putsXLCD(parameter_data[param].units_msg);

   return;
}

void Run_Screen(void)
{
	unsigned int temp;
	unsigned char lcd_char[7];
	unsigned long ltemp;
	
	while(BusyXLCD());              	// Wait if LCD busy
   SetDDRamAddr(0x00);					// Sets address to origin
	
	if (interface_flags.RUN_FRAME==0)
	{
		while(BusyXLCD());
		putsXLCD("RUN  DEMAND=");
		while(BusyXLCD());
		temp=((unsigned long)filtered_pot*100)/1023;
		uint_to_string(temp,&lcd_char[0]);
		putsXLCD(&lcd_char[2]);				// Note offset in address as
		while(BusyXLCD());					// demand only ever 100% max
		putsXLCD("%");

		ltemp=((unsigned long)filtered_vdc*10);
		ltemp*=((unsigned long)user_parameters_RAM[29]);
		temp=ltemp/((unsigned long)user_parameters_RAM[28]*ADC_GAIN);
		while(BusyXLCD());              	// Wait if LCD busy
		SetDDRamAddr(0x40);					// Move To Second Line
		while(BusyXLCD());
		uint_to_string(temp,&lcd_char[0]);
		// Add in decimal point as Vdc scaling gives 100's of mV
		lcd_char[6]='\0';						// Null terminate
		lcd_char[5]=lcd_char[4];			// Shift decimal fraction down
		lcd_char[4]='.';						// Add in decimal point
		putsXLCD(&lcd_char[1]);				// Note offset in address
		while(BusyXLCD());					// As VDC always less than 999V
		putsXLCD("V  ");
		uint_to_string(filtered_rpm,&lcd_char[0]);
		while(BusyXLCD());
		putsXLCD(&lcd_char[0]);
		while(BusyXLCD());
		putsXLCD("RPM");
	}
	else
	{
		while(BusyXLCD());
		putsXLCD("RUN ");
		while(BusyXLCD());
		temp=user_parameters_RAM[1];
		putsXLCD(&lcd_mode_msg[temp][0]);
		
		// Calculate phase advance in 1/10s of an electrical degree
		ltemp=((unsigned long)(phase_advance-TIME_CORRECTION)*1800);
		temp=ltemp/period_measurement;
		// Clamp to 30 degrees. phase_advance variable can be > 30
		// but commutation code limits it to 30.
		if (temp>300)	temp=300;
		while(BusyXLCD());              	// Wait if LCD busy
		SetDDRamAddr(0x40);					// Move To Second Line
		while(BusyXLCD());
		uint_to_string(temp,&lcd_char[0]);
		// Add in decimal point as phase advance calculated in
		// 1/10ths of a degree
		lcd_char[6]='\0';						// Null terminate
		lcd_char[5]=lcd_char[4];			// Shift decimal fraction down
		lcd_char[4]='.';						// Add in decimal point
		putsXLCD(&lcd_char[2]);				// Note offset in address
		while(BusyXLCD());					// As advance always less than 30
		putsXLCD("degs");
		uint_to_string(filtered_rpm,&lcd_char[0]);
		while(BusyXLCD());
		putsXLCD(&lcd_char[0]);
		while(BusyXLCD());
		putsXLCD("RPM");
	}
	return;
}
	




void uint_to_string(unsigned int value,unsigned char *display_str)
{

	unsigned char i , zero_flag; 

	display_str[0] = '0';
	while (value >= 10000)
   {
   	display_str[0] ++;
    	value -= 10000;
   }

	display_str[1] = '0';
	while (value >= 1000)
   {
   	display_str[1] ++;
   	value -= 1000;
   }

	display_str[2] = '0';
	while (value >= 100)
   {
   	display_str[2] ++;
   	value -= 100;
   }

	display_str[3] = '0';
	while (value >= 10)
   {
   	display_str[3] ++;
   	value -= 10;
   }

	display_str[4] = '0'+ value;

   /* Now blank off any leading zeros */

	zero_flag = TRUE;
	for (i=0;i<4;i++)
   {
    	if ((zero_flag) && (display_str[i] == '0'))	   
      	display_str[i]  = ' ';        
    	else
        	zero_flag = FALSE;
   }
	display_str[5]='\0';
	return;
}
