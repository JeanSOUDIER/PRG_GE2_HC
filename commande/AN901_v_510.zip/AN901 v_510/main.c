/**********************************************************************
 *                                                                     *
 *                        Software License Agreement                   *
 *                                                                     *
 *    The software supplied herewith by Microchip Technology           *
 *    Incorporated (the "Company") for its dsPIC controller            *
 *    is intended and supplied to you, the Company's customer,         *
 *    for use solely and exclusively on Microchip dsPIC                *
 *    products. The software is owned by the Company and/or its        *
 *    supplier, and is protected under applicable copyright laws. All  *
 *    rights are reserved. Any use in violation of the foregoing       *
 *    restrictions may subject the user to criminal sanctions under    *
 *    applicable laws, as well as to civil liability for the breach of *
 *    the terms and conditions of this license.                        *
 *                                                                     *
 *    THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION.  NO           *
 *    WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING,    *
 *    BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND    *
 *    FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE     *
 *    COMPANY SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL,  *
 *    INCIDENTAL OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.  *
 *                                                                     *
  **********************************************************************/

 /**********************************************************************
 *                                                                     * 
 *    Author: Smart Power Soutions, LLP                                * 
 *                                                                     *
 *    Filename:       main.c                                           *
 *    Date:           11/01/06                                         *
 *    File Version:   5.10                                             *
 *    Project:        53                                               *
 *    Drawing:        2                                                *
 *                                                                     *
 *    Tools used:    MPLAB C30 Compiler v 2.03                         *
 *                                                                     *
 *    Linker File:    p30f6010a.gld                                    *
 *                                                                     *
 *                                                                     *
 ***********************************************************************
 *	Code Description
 *  
 *  This is the main function for the BLDC application.  This code 
 *  calls the setup routines, initializes system variables and
 *  parameters, enables interrupts, and then goes into a polling loop.
 *  The main polling loop clears the WDT and runs the medium (10msec)
 *  and slow (100msec) event handlers when appropriate.
 *  
 **********************************************************************/

#include "general.h"
#include "hardware.h"
#include "defs.h"
#include "xlcd.h"
#include "extern_globals.h"

/*********************************************************************/
// Config directive to set configuration bits

_FOSC(CSW_FSCM_OFF & XT_PLL8);
_FWDT(WDT_OFF);
_FBORPOR(PBOR_ON & BORV_20 & PWRT_64 & MCLR_EN);


extern void setup_ports(void);
extern void setup_motor_pwms(void);
extern void setup_adc(void);
extern void setup_qei(void);
extern void setup_timers(void);

extern void OpenXLCD(unsigned char);
extern void process_parameters(void);

extern void medium_event_handler(void);
extern void slow_event_handler(void);


extern void process_parameters(void);

int main()
{
	unsigned char i;
	
	// Check if POR(or EXTR probably caused by ICD)
	// If detected clear off RCON
	if ((RCONbits.POR==TRUE) || (RCONbits.EXTR==TRUE))
	{
		RCON=0;	
	}
	// Now check for Trap, Illegal Operand, S/W Reset or WDT
	if ((RCONbits.TRAPR==TRUE) || (RCONbits.IOPUWR==TRUE) || \
		 (RCONbits.SWR==TRUE)	|| (RCONbits.WDTO==TRUE))
	{
		// Clear WDT and drive LED4 at 20% Duty
		while(1)
		{
			ClrWdt();
			LED4=0;
			for (i=0;i<255;i++);
			LED4=1;
			for (i=0;i<63;i++);
		}
	}
	run_state=INITIALIZING;
	// Set up peripherals - see setup.c for source code
	setup_ports();
	// Note interrupts must not be running during setup_motor_pwms()
	// as config registers are written to set firing polarity
	setup_motor_pwms();
	setup_adc();
	setup_qei();
	setup_timers();

	// Reset Power Module using delay due to screen initialization 
	// to ensure don't violate min pulse width of 2us at 12C671 PIC
	// in the power module
		
	FAULT_RESET=TRUE;
	IFS2bits.FLTAIF=0;

	// Enable All types ofMath Error Traps
	INTCON1bits.OVATE=TRUE;
	INTCON1bits.OVBTE=TRUE;
	INTCON1bits.COVTE=TRUE;
	// Make the FAULT A Interrupt highest priority=7
	IPC10bits.FLTAIP=7;
		
	// Enable interrupts
	// NB T2 used for Output Compare is not enabled
	// here but only when commutation is required.
	// The same goes for T1 which is used as a guard
	// timer to catch a missed zero crossing event.
	IEC2bits.PWMIE = 1;
	IEC2bits.FLTAIE=1;
	IEC0bits.ADIE = 1;
	// Set ACQUIRE2 flag high to force capture of all three
	// phase voltage channels so offsets can be calibrated
	// out in process_parameters
	control_flags.ACQUIRE2=TRUE;
	// Now actually initialize display which takes sufficient
	// time to easily ensure have valid ADC readings
	OpenXLCD(FOUR_BIT&LINES_5X7);
	// Clear ACQUIRE2 flag
	control_flags.ACQUIRE2=FALSE;
	
	FAULT_RESET=FALSE;
		
	// Now force any variables which depend on user_parameters
	// to be calculated by calling process_parameters 
	process_parameters();
	
	run_state=STANDBY;
		
	// Main background loop starts here		
	while(1)
	{
		ClrWdt();
		medium_event_handler();								
		slow_event_handler();
	}	
}
