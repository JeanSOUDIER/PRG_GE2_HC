IMPRESSION :
(AssLogo - logo1-1) et (AssLogo - logo2-1) à ajouter ensemble, en mulitmatériaux rouge(2-1) et jaune(1-1), sans support, 20% de densité, à faire en 2 exemplaires.
(attache_pale) monofil, sans support, 20% de densité, à faire en 1 exemplaire.
(P4) à tourner de 90° sur l'axe X, monofil, avec support, 20% de densité, à faire en 1 exemplaire.
(P4b) monofil, sans support, 20% de densité, à faire en 1 exemplaire.
(P12) à tourner de 90° sur l'axe X, monofil, avec support, 20% de densité, à faire en 1 exemplaire.
(piece_led) à tourner de -90° sur l'axe Y, sans support, 20% de densité, à faire en 4 exemplaires.
(protec3c) à tourner de 180° sur l'axe X, monofil, sans support, 20% de densité, à faire en 1 exemplaire.
(support1) à pivoter de -90° sur l'axe X, monofil, sans support, 20% de densité, à faire en 1 exemplaire.
(support2) monofil, sans support, 20% de densité, à faire en 1 exemplaire.
(tige_servo) monofil, sans support, 20% de densité, à faire en 1 exemplaire.

CARTON PLUME :
(P1) en 2 exemplaires.
(P3) en 1 exemplaire.
(P5) en 2 exemplaires.
(P7) en 1 exemplaire.
(P8) en 1 exemplaire.
(P10) en 1 exemplaire.
(P11) en 1 exemplaire.
(P13) en 1 exemplaire.

Assemblage :
1. AssD, AssG
2. AssBase
3. AssCarte
4. AssGouv
5. AssPhare (en 4 exemplaires)
6. AssProtec
7. AssToitMot
8. AssStruct
9. AssTotal
